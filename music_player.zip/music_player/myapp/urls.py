from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path("", views.register, name="register"),
    path("login/", views.login_user, name="login_user"),
    path("logout/", views.logout_user, name="logout_user"),
    path("upload/", views.upload_song, name="upload_song"),
    path("homepage/", views.homepage, name="homepage"),
    path("add_to_playlist/<int:song_id>/", views.add_to_playlist, name="add_to_playlist"),
    path("playlist/<int:playlist_id>/", views.playlist_detail, name="playlist_detail"),
]
