from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages 
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required, user_passes_test, permission_required
from .forms import UserRegisterForm, ProfileUpdateForm, SongForm
from .models import Playlist, Song
from .models import Playlist, Song, Profile

# Create your views here.    
# Create your views here.
def register(request):
    if request.method == 'POST':
        u_form = UserRegisterForm(request.POST)
        p_form = ProfileUpdateForm(request.POST, request.FILES)
        if u_form.is_valid() and p_form.is_valid():
            user = u_form.save()
            profile = p_form.save(commit=False)
            profile.user = user
            profile.save()
            username = u_form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}! You can now log in.')
            return redirect('login_user') # Or redirect to a login page
    else:
        u_form = UserRegisterForm()
        p_form = ProfileUpdateForm()

    context = {'u_form': u_form, 'p_form': p_form}
    return render(request, 'register_user.html', context)

def login_user(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                return redirect("homepage")
            else:
                messages.error(request,"Invalid username or password.")
        else:
            messages.error(request,"Invalid username or password.")
    form = AuthenticationForm()
    return render(request=request, template_name="login_user.html", context={"form":form})

@login_required
def logout_user(request):
    logout(request)
    messages.info(request, "You have successfully logged out.") 
    return redirect("login_user")



@login_required
@user_passes_test(lambda u: u.is_superuser)
def upload_song(request):
    if request.method == 'POST':
        form = SongForm(request.POST, request.FILES)
        if form.is_valid():
            song = form.save(commit=False)
            song.uploaded_by = request.user
            song.save()
            messages.success(request, 'Song uploaded successfully!')
            return redirect('hello_world')
    else:
        form = SongForm()
    return render(request, 'upload_song.html', {'form': form})

@login_required
def homepage(request):
    songs = Song.objects.all()
    playlists = []
    if request.user.is_authenticated:
        playlists = Playlist.objects.filter(user=request.user)

    context = {'songs': songs, 'playlists': playlists}
    return render(request, 'homepage.html',context)

@login_required
def add_to_playlist(request, song_id):
    try:
        song = Song.objects.get(id=song_id)
        # Get the user's first playlist, or create one if it doesn't exist.
        playlist, created = Playlist.objects.get_or_create(
            user=request.user, 
            defaults={'name': f"{request.user.username}'s Playlist"}
        )
        playlist.songs.add(song)
        messages.success(request, f"'{song.title}' added to your playlist '{playlist.name}'.")
    except Song.DoesNotExist:
        messages.error(request, "This song does not exist.")
    
    return redirect("homepage")

@login_required
def playlist_detail(request, playlist_id):
    # Ensure user can only see their own playlists
    playlist = get_object_or_404(Playlist, id=playlist_id, user=request.user)
    return render(request, 'playlist_detail.html', {'playlist': playlist})