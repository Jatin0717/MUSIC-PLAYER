from django.contrib import admin
from .models import Profile, Song, Playlist

# Register your models here.
admin.site.register(Profile)
admin.site.register(Song)
admin.site.register(Playlist)
